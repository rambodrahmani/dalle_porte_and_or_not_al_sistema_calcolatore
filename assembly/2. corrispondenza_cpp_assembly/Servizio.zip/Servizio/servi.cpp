#include<iostream>
using namespace std;
extern "C" char leggisucc()
{	char c; cin.get(c); return c;
}
extern "C" char leggichar()
{	char c; cin >> c; return c;
}
extern "C" int leggiint()
{	int i; cin >> i; return i;
}
extern "C" unsigned leggiex()
{	unsigned u; cin >> hex >> u >> dec; return u;
} 
extern "C" void scrivisucc(char c)
{	cout.put(c);
}
extern "C" void scrivichar(char c)
{	cout << c << ' ';
}
extern "C" void scriviint(int i)
{	cout << i << ' ';
}
extern "C" void scriviex(unsigned int u)
{	cout << hex << u << dec << ' ';
}
extern "C" void nuovalinea()
{	cout << endl;
}